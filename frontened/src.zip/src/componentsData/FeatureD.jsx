export const FeaturesD=[
  {
    data:1,
    title:"Product Designer",
    company:"TechSolutions",
    location: "Mumbai, India",
    experience : "3+ yrs"
    
  },
  {
    data:2,
    title:"Software Engineer",
    company:"HealthFlue",
    location :"Hyderabad, India",
    experience : "2+ yrs"
  },
  {
    data:3,
    title:"Frontend Developer",
    company:"TechNova Solutions",
    location : "Bengluru, India ",
    experience : "0-2 yrs"
  },
  {
    data:4,
    title:"Full Stack Developer",
    company:"NextGen Labs",
    location : "Pune, India ",
    experience : "0-2 yrs"
  },
  {
  data: 5,
  title: "DevOps Engineer",
  company: "CloudNova Solutions",
  location: "Chennai, India",
  experience: "0-1 yrs"
},
{
  data: 6,
  title: "Data Analyst",
  company: "InsightSphere Analytics",
  location: "Noida, India",
  experience: "1+ yrs"
},
{
  data: 7,
  title: "Data Science",
  company: "AppForge Technologies",
  location: "Indore, India",
  experience: "0-1 yrs"
},
{
  data: 8,
  title: "Backend Developer",
  company: "QualityFirst Labs",
  location: "Kochi, India",
  experience: "0-2 yrs"
}

]