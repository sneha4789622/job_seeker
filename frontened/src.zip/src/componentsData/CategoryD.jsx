// import code from "../assets/code.svg";
// import dataScience from "../assets/data-science.svg";
// import design from "../assets/web-design-tool.svg";
// import marketing from "../assets/marketing.svg";
// import hr from "../assets/human-resource.svg";
// import finance from "../assets/finance.svg";
// import support from "../assets/viral-marketing.svg";
// import internship from "../assets/internship.svg";

// export const categories = [
//   {
//     code: 1,
//     img: code,
//     name: "Software Development",
//   },
//   {
//     code: 2,
//     img: dataScience,
//     name: "Data & Analytics",
//   },
//   {
//     code: 3,
//     img: design,
//     name: "Design & Creative",
//   },
//   {
//     code: 4,
//     img: marketing,
//     name: "Marketing & Sales",
//   },
//   {
//     code: 5,
//     img: hr,
//     name: "Human Resources (HR)",
//   },
//   {
//     code: 6,
//     img: finance,
//     name: "Finance & Accounting",
//   },
//   {
//     code: 7,
//     img: support,
//     name: "Customer Support",
//   },
//   {
//     code: 8,
//     img: internship,
//     name: "Internship",
//   },
// ];
