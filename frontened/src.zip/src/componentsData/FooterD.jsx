export const Companies=[
  {
    title:"Job Fields",
    links :[
      {key:1, name:"IT & Software", href:"#"},
      {key:2, name:"Digital Marketing", href:"#"},
      {key:3, name:"UI/UX Designer", href:"#"},
      {key:4, name:"Human Resources", href:"#"},
      {key:5, name:"Frontend Developloper", href:"#"},
      {key:6, name:"Backend Developloper", href:"#"},
      {key:7, name:"Full stack Developer", href:"#"},
      {key:8, name:"Data Science", href:"#"},
      {key:9, name:"AI & ML", href:"#"}
    ]
  },
  {
    title:"Top Companies",
    links :[
      {key:1, name:"Google", href:"#"},
      {key:2, name:"Microsoft", href:"#"},
      {key:3, name:"Amazon", href:"#"},
      {key:4, name:"Infosys", href:"#"},
      {key:5, name:"TCS", href:"#"},
      {key:6, name: "Wipro", href:"#"},
      {key:7, name:"Flipkart", href:"#"},
      {key:8, name:"Reliance", href:"#"},
      {key:9, name:"Zoho", href:"#"}
    ]
  },
  {
    title:"Job location",
    links :[
      {key:1, name:"Banglore", href:"#"},
      {key:2, name:"Hydrabad", href:"#"},
      {key:3, name:"Pune", href:"#"},
      {key:4, name:"Delhi NCR", href:"#"},
      {key:5, name:"Mumbai", href:"#"},
      {key:6, name:"Chennai", href:"#"},
      {key:7, name:"Kolkata", href:"#"},
      {key:8, name:"Remote Jobs", href:"#"},
      {key:9, name:"International Jobs", href:"#"}
    ]
  },
  {
    title:"Comapny Info",
    links :[
      {key:1, name:"About Us", href:"#"},
      {key:2, name:"Contact us", href:"#"},
      {key:3, name:"Privacy policy", href:"#"},
      {key:4, name:"Terms & Conditions", href:"#"},
    ]
  }

]

